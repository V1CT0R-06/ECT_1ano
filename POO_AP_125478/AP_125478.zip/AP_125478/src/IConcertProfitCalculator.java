public interface IConcertProfitCalculator {
    double calculateConcertProfit(Concert concert);
}    

